<?php
	$i= 1;
	for (;;) { 
		if($i>4){
			break;//跳出整个循环
		}
		$i++;
	}
	echo "i = ".$i;
?>