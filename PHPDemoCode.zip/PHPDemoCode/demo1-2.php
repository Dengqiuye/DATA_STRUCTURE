<?php
	echo "当前文件的路径为：".__FILE__;
	//.表示字符串的拼接
	echo "<br>";
	echo "当前php的版本：".PHP_VERSION;
	echo "<br>";
	echo "当前操作系统的内核为：".PHP_OS;
?>