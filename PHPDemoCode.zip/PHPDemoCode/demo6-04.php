<?php
//处理html字符串的一些方式
$str1 = "aaa \n bbb";
echo nl2br($str1);//将字符串中的\n，前面自动添加<br>
//将html代码转化为html实体
?>