<?php
	$week = "a";
	switch($week){
		case "a": echo "星期一";
			# code...
			break;
		case 2:echo "星期二";
			# code...
			break;
		default: echo "输入错误";
	}
?>