<?php
//100!
$i= 1;
$sum=1;
for($i=1;$i<=100;$i++){
	$sum*=$i;
}
echo "sum = ".$sum;
?>