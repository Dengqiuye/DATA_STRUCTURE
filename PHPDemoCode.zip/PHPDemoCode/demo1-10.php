<?php
	$x = 'a';//++
	$x++;
	echo "x = ".$x;
	$y = 'abcz';
	$y++;//$y = $y +1;

	echo "y = ".$y;

?>